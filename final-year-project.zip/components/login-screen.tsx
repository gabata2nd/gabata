'use client'

import { FormEvent, useState } from 'react'
import { ArrowRight, Eye, EyeOff, ShieldCheck } from 'lucide-react'
import { DefenceDashboard } from '@/components/defence-dashboard'

const loginRoles = ['Administrator', 'Student', 'Supervisor', 'Panel Member']

export function LoginScreen() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loginAs, setLoginAs] = useState('Administrator')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [error, setError] = useState('')

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!username.trim() || !password.trim()) {
      setError('Enter your username and password to continue.')
      return
    }
    setError('')
    setIsLoggedIn(true)
  }

  if (isLoggedIn) return <DefenceDashboard />

  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-4 py-8 text-foreground sm:px-6">
      <div className="grid w-full max-w-5xl overflow-hidden rounded-3xl border border-border bg-card shadow-xl lg:grid-cols-[0.9fr_1.1fr]">
        <section className="hidden flex-col justify-between bg-primary p-10 text-primary-foreground lg:flex">
          <div>
            <div className="flex items-center gap-3"><div className="flex size-11 items-center justify-center rounded-xl bg-primary-foreground/15"><ShieldCheck className="size-6" /></div><div><p className="font-semibold tracking-tight">DefenceFlow</p><p className="text-xs text-primary-foreground/70">Academic operations</p></div></div>
            <div className="mt-24 max-w-sm"><p className="text-xs font-medium uppercase tracking-[0.2em] text-primary-foreground/70">Institutional defence management</p><h1 className="mt-4 text-4xl font-semibold leading-tight tracking-tight">Every defence, clearly scheduled.</h1><p className="mt-5 text-sm leading-6 text-primary-foreground/75">Coordinate students, supervisors, panels, venues, and presentation times from one reliable workspace.</p></div>
          </div>
          <p className="text-xs text-primary-foreground/60">Secure access for authorized academic staff and students.</p>
        </section>

        <section className="flex items-center p-6 sm:p-10 lg:p-14">
          <div className="w-full max-w-md mx-auto">
            <div className="mb-8 lg:hidden"><div className="flex items-center gap-3"><div className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground"><ShieldCheck className="size-5" /></div><div><p className="font-semibold tracking-tight">Defence<span className="text-primary">Flow</span></p><p className="text-xs text-muted-foreground">Academic operations</p></div></div></div>
            <p className="text-sm font-medium text-primary">Welcome back</p>
            <h2 className="mt-2 text-3xl font-semibold tracking-tight">Sign in to your workspace</h2>
            <p className="mt-3 text-sm leading-6 text-muted-foreground">Use your institutional account to access defence schedules and project information.</p>

            <form onSubmit={handleSubmit} className="mt-8 flex flex-col gap-5">
              <div className="flex flex-col gap-2"><label htmlFor="username" className="text-sm font-medium">Username</label><input id="username" value={username} onChange={(event) => setUsername(event.target.value)} placeholder="e.g. admin.office" autoComplete="username" className="h-11 rounded-xl border border-input bg-background px-3 text-sm outline-none transition focus:ring-2 focus:ring-ring" /></div>
              <div className="flex flex-col gap-2"><div className="flex items-center justify-between"><label htmlFor="password" className="text-sm font-medium">Password</label><button type="button" className="text-xs font-medium text-primary hover:underline">Forgot password?</button></div><div className="relative"><input id="password" type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Enter your password" autoComplete="current-password" className="h-11 w-full rounded-xl border border-input bg-background px-3 pr-11 text-sm outline-none transition focus:ring-2 focus:ring-ring" /><button type="button" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? 'Hide password' : 'Show password'} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">{showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}</button></div></div>
              <div className="flex flex-col gap-2"><label htmlFor="login-as" className="text-sm font-medium">Login as</label><select id="login-as" value={loginAs} onChange={(event) => setLoginAs(event.target.value)} className="h-11 rounded-xl border border-input bg-background px-3 text-sm outline-none transition focus:ring-2 focus:ring-ring">{loginRoles.map((role) => <option key={role}>{role}</option>)}</select><p className="text-xs text-muted-foreground">Your role controls the information and actions available after sign in.</p></div>
              {error && <p role="alert" className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>}
              <button type="submit" className="flex h-11 items-center justify-center gap-2 rounded-xl bg-primary px-4 text-sm font-medium text-primary-foreground shadow-sm transition hover:opacity-90">Sign in as {loginAs} <ArrowRight className="size-4" /></button>
            </form>
            <p className="mt-8 text-center text-xs text-muted-foreground">Need access? Contact your department administrator.</p>
          </div>
        </section>
      </div>
    </main>
  )
}
