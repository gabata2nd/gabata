'use client'

import { useMemo, useState } from 'react'
import {
  AlertTriangle,
  ArrowUpRight,
  Bell,
  CalendarDays,
  CheckCircle2,
  ChevronDown,
  ClipboardList,
  Clock3,
  FileBarChart2,
  LayoutDashboard,
  Menu,
  PanelTop,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Users,
  X,
} from 'lucide-react'

const schedules = [
  { student: 'Amara Okafor', project: 'Campus Shuttle Tracker', supervisor: 'Dr. Mensah', panel: 'Panel A', date: 'Sep 04, 2026', time: '09:00 – 09:30', venue: 'Lab 204', department: 'Software Engineering', status: 'Scheduled' },
  { student: 'Daniel Boateng', project: 'Smart Clinic Queue', supervisor: 'Prof. Adebayo', panel: 'Panel B', date: 'Sep 04, 2026', time: '10:00 – 10:30', venue: 'Innovation Hub', department: 'Computer Science', status: 'Scheduled' },
  { student: 'Ifeoma Eze', project: 'FarmLink Marketplace', supervisor: 'Dr. Mensah', panel: 'Panel C', date: 'Sep 05, 2026', time: '11:30 – 12:00', venue: 'Lab 201', department: 'Information Systems', status: 'Scheduled' },
  { student: 'Kwame Asante', project: 'SecureVote Platform', supervisor: 'Dr. Ndlovu', panel: 'Panel A', date: 'Sep 05, 2026', time: '14:00 – 14:30', venue: 'Seminar Room', department: 'Software Engineering', status: 'Pending' },
  { student: 'Zainab Yusuf', project: 'Museo Digital Archive', supervisor: 'Prof. Adebayo', panel: 'Panel D', date: 'Sep 06, 2026', time: '09:30 – 10:00', venue: 'Lab 204', department: 'Computer Science', status: 'Scheduled' },
]

const roles = ['Administrator', 'Student', 'Supervisor', 'Panel Member']

export function DefenceDashboard() {
  const [role, setRole] = useState('Administrator')
  const [active, setActive] = useState('Overview')
  const [query, setQuery] = useState('')
  const [department, setDepartment] = useState('All departments')
  const [showConflict, setShowConflict] = useState(false)
  const [mobileNav, setMobileNav] = useState(false)

  const visibleSchedules = useMemo(() => schedules.filter((item) => {
    const matchesQuery = `${item.student} ${item.project} ${item.venue}`.toLowerCase().includes(query.toLowerCase())
    const matchesDepartment = department === 'All departments' || item.department === department
    return matchesQuery && matchesDepartment
  }), [query, department])

  const navItems = [
    { label: 'Overview', icon: LayoutDashboard },
    { label: 'Defence timetable', icon: CalendarDays },
    { label: 'Students', icon: Users },
    { label: 'Projects', icon: ClipboardList },
    { label: 'Venues & panels', icon: PanelTop },
    { label: 'Reports', icon: FileBarChart2 },
  ]

  const roleCopy = role === 'Administrator'
    ? { eyebrow: 'Monday, August 31, 2026', title: 'Good morning, Administrator', description: 'Here is what is happening across project defences this week.' }
    : role === 'Student'
      ? { eyebrow: 'Student portal', title: 'Welcome back, Amara', description: 'Everything you need for your upcoming project defence.' }
      : role === 'Supervisor'
        ? { eyebrow: 'Supervisor portal', title: 'Good morning, Dr. Mensah', description: 'Keep track of your students and their defence readiness.' }
        : { eyebrow: 'Panel member portal', title: 'Your defence schedule', description: 'Review assigned projects, venues, and presentation times.' }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-border bg-sidebar px-4 py-5 transition-transform lg:translate-x-0 ${mobileNav ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between px-2">
          <div className="flex items-center gap-3"><div className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground"><ShieldCheck /></div><div><p className="font-semibold tracking-tight">Defence<span className="text-primary">Flow</span></p><p className="text-xs text-muted-foreground">Academic operations</p></div></div>
          <button className="text-muted-foreground lg:hidden" onClick={() => setMobileNav(false)} aria-label="Close navigation"><X /></button>
        </div>
        <div className="mt-10 flex flex-col gap-1">
          <p className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Workspace</p>
          {navItems.map((item) => { const Icon = item.icon; return <button key={item.label} onClick={() => { setActive(item.label); setMobileNav(false) }} className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm transition-colors ${active === item.label ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-sm' : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'}`}><Icon className="size-4" />{item.label}</button> })}
        </div>
        <div className="mt-auto flex flex-col gap-1"><button className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-sidebar-foreground/70 hover:bg-sidebar-accent"><Settings2 className="size-4" />Settings</button><div className="mt-3 flex items-center gap-3 border-t border-sidebar-border px-2 pt-4"><div className="flex size-9 items-center justify-center rounded-full bg-accent text-sm font-semibold text-accent-foreground">AO</div><div className="min-w-0"><p className="truncate text-sm font-medium">Admin Office</p><p className="truncate text-xs text-muted-foreground">admin@institution.edu</p></div><ChevronDown className="ml-auto size-4 text-muted-foreground" /></div></div>
      </aside>

      <main className="lg:pl-64">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-background/95 px-4 backdrop-blur sm:px-8"><div className="flex items-center gap-3"><button className="rounded-lg p-2 hover:bg-muted lg:hidden" onClick={() => setMobileNav(true)} aria-label="Open navigation"><Menu /></button><p className="hidden text-sm text-muted-foreground sm:block">Institutional Defence Management</p></div><div className="flex items-center gap-3"><button className="relative rounded-lg p-2 text-muted-foreground hover:bg-muted" aria-label="Notifications"><Bell className="size-5" /><span className="absolute right-1.5 top-1.5 size-2 rounded-full bg-destructive" /></button><div className="hidden h-6 w-px bg-border sm:block" /><div className="flex items-center gap-2"><div className="flex size-8 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">AO</div><span className="hidden text-sm font-medium sm:block">Admin Office</span></div></div></header>
        <div className="mx-auto max-w-[1440px] px-4 py-7 sm:px-8 lg:px-10">
          <div className="mb-7 flex flex-col justify-between gap-5 xl:flex-row xl:items-end"><div><p className="mb-2 text-xs font-medium uppercase tracking-[0.16em] text-primary">{roleCopy.eyebrow}</p><h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">{roleCopy.title}</h1><p className="mt-2 text-sm text-muted-foreground">{roleCopy.description}</p></div><div className="flex flex-col gap-2 sm:flex-row sm:items-center"><label className="sr-only" htmlFor="role">Preview role</label><select id="role" value={role} onChange={(e) => setRole(e.target.value)} className="h-10 rounded-lg border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring">{roles.map((item) => <option key={item}>{item}</option>)}</select><button onClick={() => setShowConflict(true)} className="flex h-10 items-center justify-center gap-2 rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground shadow-sm hover:opacity-90"><Plus className="size-4" />Create schedule</button></div></div>

          {role === 'Administrator' ? <>
            <section className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">{[['Students','248','+12 this month',Users],['Projects','186','92% assigned',ClipboardList],['Supervisors','42','Active faculty',Users],['Panel members','36','Across 8 panels',PanelTop],['Upcoming defences','24','This week',CalendarDays],['Completed','162','86% of total',CheckCircle2]].map(([label,value,detail,Icon]) => <div key={String(label)} className="rounded-xl border border-border bg-card p-4"><div className="mb-4 flex items-center justify-between"><span className="text-xs text-muted-foreground">{label}</span><Icon className="size-4 text-primary" /></div><p className="text-2xl font-semibold tracking-tight">{value}</p><p className="mt-1 text-[11px] text-muted-foreground">{detail}</p></div>)}</section>
            <section className="mt-6 grid gap-6 xl:grid-cols-[1fr_0.38fr]"><div className="rounded-xl border border-border bg-card"><div className="flex flex-col gap-3 border-b border-border p-5 sm:flex-row sm:items-center sm:justify-between"><div><h2 className="font-semibold">Defence timetable</h2><p className="mt-1 text-xs text-muted-foreground">Upcoming presentations across the institution</p></div><button onClick={() => setActive('Defence timetable')} className="flex items-center gap-1 text-xs font-medium text-primary hover:underline">View full timetable <ArrowUpRight className="size-3.5" /></button></div><div className="flex flex-col gap-3 border-b border-border p-4 sm:flex-row"><div className="relative flex-1"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><input aria-label="Search timetable" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search student, project or venue..." className="h-10 w-full rounded-lg border border-input bg-background pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-ring" /></div><select aria-label="Filter department" value={department} onChange={(e) => setDepartment(e.target.value)} className="h-10 rounded-lg border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"><option>All departments</option><option>Software Engineering</option><option>Computer Science</option><option>Information Systems</option></select><button className="flex h-10 items-center justify-center gap-2 rounded-lg border border-input px-3 text-sm hover:bg-muted"><SlidersHorizontal className="size-4" />Filters</button></div><div className="overflow-x-auto"><table className="w-full min-w-[760px] text-left text-sm"><thead className="bg-muted/40 text-xs text-muted-foreground"><tr><th className="px-5 py-3 font-medium">Student / project</th><th className="px-3 py-3 font-medium">Date & time</th><th className="px-3 py-3 font-medium">Panel</th><th className="px-3 py-3 font-medium">Venue</th><th className="px-5 py-3 font-medium">Status</th></tr></thead><tbody className="divide-y divide-border">{visibleSchedules.slice(0,4).map((item) => <tr key={item.student} className="hover:bg-muted/30"><td className="px-5 py-4"><p className="font-medium">{item.student}</p><p className="mt-0.5 text-xs text-muted-foreground">{item.project}</p></td><td className="px-3 py-4"><p className="text-xs font-medium">{item.date}</p><p className="mt-0.5 text-xs text-muted-foreground">{item.time}</p></td><td className="px-3 py-4 text-xs">{item.panel}</td><td className="px-3 py-4 text-xs">{item.venue}</td><td className="px-5 py-4"><span className={`rounded-full px-2 py-1 text-[11px] font-medium ${item.status === 'Pending' ? 'bg-accent text-accent-foreground' : 'bg-primary/10 text-primary'}`}>{item.status}</span></td></tr>)}</tbody></table></div></div>
              <div className="flex flex-col gap-6"><div className="rounded-xl border border-border bg-card p-5"><div className="flex items-start justify-between"><div><h2 className="font-semibold">Schedule health</h2><p className="mt-1 text-xs text-muted-foreground">Conflict-free assignments</p></div><div className="flex size-10 items-center justify-center rounded-full bg-primary/10 text-primary"><CheckCircle2 className="size-5" /></div></div><p className="mt-6 text-4xl font-semibold tracking-tight">98.4<span className="text-xl">%</span></p><div className="mt-4 h-2 overflow-hidden rounded-full bg-muted"><div className="h-full w-[98.4%] rounded-full bg-primary" /></div><p className="mt-3 text-xs text-muted-foreground">182 of 186 projects scheduled without conflicts</p></div><div className="rounded-xl border border-destructive/30 bg-destructive/5 p-5"><div className="flex items-start gap-3"><div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-destructive/10 text-destructive"><AlertTriangle className="size-4" /></div><div><h2 className="font-semibold">Needs attention</h2><p className="mt-1 text-xs leading-5 text-muted-foreground">4 schedule conflicts need review before publishing.</p><button onClick={() => setShowConflict(true)} className="mt-4 text-xs font-semibold text-destructive hover:underline">Review conflicts <ArrowUpRight className="ml-1 inline size-3" /></button></div></div></div></div></section>
          </> : <RoleView role={role} schedules={visibleSchedules} />}
        </div>
      </main>

      {showConflict && <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/30 p-4" role="dialog" aria-modal="true" aria-labelledby="conflict-title"><div className="w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-xl"><div className="flex items-start justify-between"><div className="flex size-11 items-center justify-center rounded-xl bg-destructive/10 text-destructive"><AlertTriangle /></div><button onClick={() => setShowConflict(false)} className="rounded-lg p-1 text-muted-foreground hover:bg-muted" aria-label="Close dialog"><X className="size-5" /></button></div><h2 id="conflict-title" className="mt-5 text-lg font-semibold">Schedule conflict detected</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">This assignment cannot be saved because <strong className="font-medium text-foreground">Panel A</strong> is already assigned to another defence on Sep 04, 2026 from 09:00 – 09:30 in Lab 204.</p><div className="mt-5 rounded-lg bg-muted/60 p-4 text-xs"><p className="font-semibold">Conflicting assignment</p><p className="mt-1 text-muted-foreground">Amara Okafor · Campus Shuttle Tracker</p></div><div className="mt-6 flex justify-end gap-3"><button onClick={() => setShowConflict(false)} className="rounded-lg border border-input px-4 py-2 text-sm hover:bg-muted">Cancel</button><button onClick={() => setShowConflict(false)} className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">Choose another slot</button></div></div></div>}
    </div>
  )
}

function RoleView({ role, schedules }: { role: string; schedules: typeof schedules }) {
  const isStudent = role === 'Student'
  const isSupervisor = role === 'Supervisor'
  return <section className="grid gap-6 lg:grid-cols-[1.3fr_0.7fr]"><div className="rounded-xl border border-border bg-card p-6"><div className="flex items-center gap-3"><div className="flex size-12 items-center justify-center rounded-xl bg-primary/10 text-primary">{isStudent ? <CalendarDays /> : isSupervisor ? <Users /> : <PanelTop />}</div><div><p className="text-xs uppercase tracking-widest text-primary">{isStudent ? 'Your next defence' : 'This week'}</p><h2 className="mt-1 text-xl font-semibold">{isStudent ? 'Campus Shuttle Tracker' : isSupervisor ? '4 students under your supervision' : '5 assigned presentations'}</h2></div></div><div className="mt-8 grid gap-4 sm:grid-cols-3">{[['Date','September 04, 2026'],['Time','09:00 – 09:30'],['Venue','Lab 204']].map(([label,value]) => <div key={label} className="rounded-lg bg-muted/50 p-4"><p className="text-xs text-muted-foreground">{label}</p><p className="mt-2 text-sm font-semibold">{value}</p></div>)}</div><div className="mt-8 flex items-center justify-between border-t border-border pt-5"><div><p className="text-xs text-muted-foreground">Assigned panel</p><p className="mt-1 text-sm font-medium">Panel A · Dr. Ndlovu, Prof. Bello</p></div><button className="rounded-lg border border-input px-3 py-2 text-xs font-medium hover:bg-muted">View details</button></div></div><div className="rounded-xl border border-border bg-card p-6"><h2 className="font-semibold">{isStudent ? 'Project information' : 'Upcoming schedule'}</h2><div className="mt-5 flex flex-col gap-4">{schedules.slice(0,3).map((item) => <div key={item.student} className="flex gap-3"><div className="mt-1 flex size-8 shrink-0 items-center justify-center rounded-lg bg-muted"><Clock3 className="size-4 text-primary" /></div><div><p className="text-sm font-medium">{isStudent ? item.project : item.student}</p><p className="mt-1 text-xs text-muted-foreground">{item.date} · {item.time}</p><p className="mt-1 text-xs text-muted-foreground">{item.venue}</p></div></div>)}</div></div></section>
}
